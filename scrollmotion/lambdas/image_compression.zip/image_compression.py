from __future__ import print_function
from PIL import Image
import boto3
import uuid
import os


def lambda_handler(event, context):
	bucket = event.get('bucket')
	original_key = event.get('original_key')
	compressed_key = event.get('compressed_key')
	quality = event.get('quality')

	try:
		s3 = boto3.client('s3')

		# Download Original Image
		original_path = '/tmp/original_{}.jpg'.format(uuid.uuid4())
		s3.download_file(bucket, original_key, original_path)

		# Compress Image
		image = Image.open(original_path)
		compressed_path = '/tmp/compressed_{}.jpg'.format(uuid.uuid4())
		image.save(compressed_path, quality=quality, optimize=True)

		# Save Compressed Image To S3
		s3.upload_file(compressed_path, bucket, compressed_key, ExtraArgs={'ContentType': 'image/jpeg'})

		# Return Compressed Image Info
		img_info = {
			'url': 'https://s3.amazonaws.com/{}/{}'.format(bucket, compressed_key),
			'size': os.path.getsize(compressed_path)
		}
		return img_info

	except Exception as e:
		print(e)
